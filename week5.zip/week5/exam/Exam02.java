package javaprogramming.week5.exam;

import java.util.ArrayList;

//Arraylist2
public class Exam02 {
    public static void main(String[] args){
        ArrayList <String> arr = new ArrayList<>();
        arr.add("사과");
        arr.add("포도");
        arr.add("딸기");
        arr.add("바나나");
        for(String fruit:arr){
            System.out.print(fruit+" ");
        }
        System.out.println("\n==============");
        System.out.println("찾는 과일 : "+ arr.get(1));
        arr.remove(1);
        for(String fruit:arr){
            System.out.print(fruit+" ");
        }
        System.out.println("\n==============");
        arr.remove("사과"); //삭제
        for(String fruit:arr){
            System.out.print(fruit+" ");
        }
        System.out.println("\n==============");
        arr.add(1,"포도"); //몇번째에 추가
        for(String fruit:arr){
            System.out.print(fruit+" ");
        }
        System.out.println("\n==============");
        arr.set(1,"키위"); //값 다른 값으로 바꾸기
        for(String fruit:arr){
            System.out.print(fruit+" ");
        }
        System.out.println("\n==============");
    }
}
