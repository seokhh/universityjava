package javaprogramming.week5.exam;

import java.util.Scanner;

//Class
class Circle { //속성(멤버변수)+메서드+ 생성자 3개로 구성
    double radius;
    String name;
    double getArea(){
        return Math.PI*radius*radius;
    }
    //객체의 이름과 면적을 출력해주는 메서드 정의
    void print(){
        System.out.println(name+"의 넓이: " + getArea());
    }
}
public class Exam06 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Circle circle = new Circle();
        System.out.print("이름을 입력하세요: ");
        circle.name = sc.next();
        System.out.print("반지름을 입력하세요: ");
        circle.radius = sc.nextDouble();
        //System.out.println(circle.name + "의 넓이: " + circle.getArea());
        circle.print();

        Circle nut = new Circle();
        nut.name = "도넛";
        nut.radius = 3.3;
        //System.out.println(nut.name+"의 넓이: " +nut.getArea());
        nut.print();
    }
}