package javaprogramming.week5.exam;

import java.util.ArrayList;

//Arraylist
public class Exam01 {

    public static void main(String[] args) {
        ArrayList<Integer> arr = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            arr.add(i);
        }
        for (int list : arr) {
            System.out.print(list + " ");
        }
        System.out.println("\n3번째 요소의 값: " + arr.get(3));
        //get 요소에 저장에 0요소부터 4번째까지 출력
        for(int i =0; i<arr.size(); i++){
            System.out.print((i) + "번째 요소의 값: " + arr.get(i)+" ");
        }
    }
}