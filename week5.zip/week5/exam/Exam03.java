package javaprogramming.week5.exam;

import java.util.Scanner;

//Exception
public class Exam03 {

    public static void main(String[] args) {
        //젯수와 피젯수를 입력받아 나누기 연산 수행
        Scanner sc = new Scanner(System.in);
        System.out.print("첫번째 정수 입력: ");
        int a = sc.nextInt();
        System.out.print("두번째 정수 입력: ");
        int b = sc.nextInt();

        try {
            int result = a / b;
        } catch (ArithmeticException e) {
            System.out.println("나누기 불가");
        } finally {
            System.out.println("try/catch문 통과");
        }
    }
}
