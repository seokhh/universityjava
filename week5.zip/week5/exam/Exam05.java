package javaprogramming.week5.exam;

import java.io.FileReader;
import java.io.IOException;

//Exception
public class Exam05 {

    public static void main(String[] args) throws IOException {
        /*
        try {
            FileReader fr = new FileReader("C:\\java\\extest.txt");
            char[] ch = new char[100];
            fr.read(ch);
            System.out.print(ch);
        } catch (IOException e) {
            e.printStackTrace(); //어떤 예외인지 찍어보겠다. (지정된 경로를 찾을 수 없습니다.)
        }
        */

        FileReader fr = new FileReader("C:\\java\\extest.txt");
        char[] ch = new char[100];
        fr.read(ch);
        System.out.print(ch);
    }
}