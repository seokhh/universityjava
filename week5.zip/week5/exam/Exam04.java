package javaprogramming.week5.exam;

import java.util.Scanner;

//Exception
public class Exam04 {

    public static void main(String[] args) {
        //5개 정수를 저장할 수 있는 배열을 선언하고 입력 받아 저장 출력
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[5];
        try {
            for (int i = 0; i <= arr.length; i++) {
                System.out.print((i + 1) + "번째 정수: ");
                arr[i] = sc.nextInt();
            }
        } catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("배열의 크기를 벗어남");
        }
    }
}