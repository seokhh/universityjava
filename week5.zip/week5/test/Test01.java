package javaprogramming.week5.test;

import java.util.ArrayList;
import java.util.Collections;

//Arraylist 예제
public class Test01 {

    public static void main(String[] args) {
        //로또 번호 랜덤하게 추출하기 배열에 0번부터 45번 까지 저장하고 랜덤하게 번호 추출
        ArrayList<Integer> arr = new ArrayList<>();
        for (int i = 0; i <= 45; i++) {
            arr.add(i);
        }
        for (int lotto : arr) {
            Collections.shuffle(arr); //배열 요소의 값을 랜덤하게 섞어주는 클래스
        }
        for (int j = 0; j < 5; j++) {
            System.out.print(arr.get(j)+" ");
        }
    }
}