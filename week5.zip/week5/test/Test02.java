package javaprogramming.week5.test;

import java.util.InputMismatchException;
import java.util.Scanner;

//Exception
public class Test02 {

    public static void main(String[] args) {
        //3개의 정수를 입력받아 입력받은 정수의 합을 구하시오
        Scanner sc = new Scanner(System.in);
        System.out.println("3개의 정수입력");
        int sum = 0,n;

        for (int i = 1; i <= 3; i++) {
            System.out.print(i + "번째 정수 입력 : ");
            try {
                n = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("정수가 아닌 값을 넣었습니다.");
                sc.next();
                i--;
                continue;
            }
            sum += n;
        }
        System.out.println("입력한 정수의 값: "+sum);
    }
}