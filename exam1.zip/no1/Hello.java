package javaprogramming.week2.exam1.no1;

public class Hello {
    public static void main(String[] args){
        Sum sum = new Sum();
        int i = 10;
        int s = sum.plus(i, 20);
        char a = '?';

        System.out.print("안녕하세요");
        System.out.println(a);
        System.out.println("석해현");
        System.out.println("컴퓨터공학부");
        System.out.println(s);
        System.out.println(10+30);
        int A = 10, B = 20;
        System.out.println(A + "+" +B + "= " + (10+20) );
        boolean bo = true;
        System.out.println(bo);
        double d = 5;
        System.out.println("실수값 출력: " +d);


    }
}