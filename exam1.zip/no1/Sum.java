package javaprogramming.week2.exam1.no1;

public class Sum {
    int plus(int a, int b){
        int result = a+b;
        return result;
    }
}
