package javaprogramming.week3;

public class Exam03 {
    public static void main(String[] args){
        int a =10, b=3;
        System.out.println(a>=b);
        System.out.println(a<=b);
        System.out.println(a==b);
        System.out.println(a!=b);
        System.out.println();
        System.out.println((a==10) && (b==10));
        System.out.println(a==10 || (b ==10));
        System.out.println(!(a==10));
    }
}