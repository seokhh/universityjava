package javaprogramming.week4.exam;

public class Exam04 {
    public static void main(String[] args){
        for(int i = 2; i<=9; i++){
            for(int k =1; k<=9; k++){
                System.out.println(i + " * " + k + " = " + (i*k));
            }
            System.out.println();
        }
    }
}
