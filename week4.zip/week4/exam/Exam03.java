package javaprogramming.week4.exam;

public class Exam03 {
    public static void main(String[] args){
        int i =1;
        do{
            System.out.println(i);
            i++;
        } while (i<=10);
    }
}
